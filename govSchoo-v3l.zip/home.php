<?php get_header(); ?>
  <section class="page-intro has-bg has-overlay blue" 
    <?php if(is_home()) {
      $img = wp_get_attachment_image_src(get_post_thumbnail_id(get_option('page_for_posts')),'full');
        $featured_image = $img[0];
    }?>
    <?php if ($featured_image ) {
          echo 'style="background-image: url('.$featured_image.')"';        
        } else {
          $placeholder = get_field('banner_green', 'options');
          echo 'style="background-image: url('.$placeholder.')"';
        }?>>
    <div class="container block-vc d-flex align-items-center justify-content-center">
      <div class="caption text-center">
        <h1 class="text-white"><?php echo wp_title() ?></h1>
      </div>
    </div>
  </section>
  <div class="container py-8 py-lg-12">
    <div class="row">
      <div class="col-lg-8 mb-8 mb-lg-0" id="content">
        <?php get_template_part('template-parts/news/news-block'); ?>
        <?php get_template_part('template-parts/programs/programs-block'); ?>
        <?php get_template_part('template-parts/exams/exams-block'); ?>
        <?php get_template_part('template-parts/results/results-block'); ?>
        <?php get_template_part('template-parts/admissions/admissions-block'); ?>
        <?php get_template_part('template-parts/fees/fees-block'); ?>
      </div>
      <div class="col-lg-4" id="sidebar">
        <div class="row">
          <div class="col-lg-7 col-lg-12 mb-6">
            <?php get_template_part('template-parts/online-education/online-featured-materials'); ?>
          </div>
          <div class="col-lg-5 col-lg-12">
            <div class="row">
              <div class="col-md-6 col-lg-12">
                <?php get_template_part('template-parts/quick-links/quick-links'); ?>
              </div>
              <div class="col-md-6 col-lg-12">
                <?php get_template_part('template-parts/featured-gallery/featured-gallery'); ?>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php get_footer(); ?>