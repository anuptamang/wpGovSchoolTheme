<?php
/*
Template Name: Information Center
*/
get_header(); ?>

<h1>Template Information Center</h1>

<?php get_footer(); ?>