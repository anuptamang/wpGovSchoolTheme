<?php get_header() ?>
<div class="base-section">
  <div class="container py-10">
    <div class="row">
      <div class="col-md-6">
        <?php get_template_part( 'blocks/not_found' ) ?>
      </div>
    </div>
  </div>
</div>
<?php get_footer() ?>
