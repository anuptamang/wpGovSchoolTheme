<?php
the_posts_pagination( array(
  'prev_text' => __( 'Previous page', 'government-school' ),
  'next_text' => __( 'Next page', 'government-school' ),
) )
?>
