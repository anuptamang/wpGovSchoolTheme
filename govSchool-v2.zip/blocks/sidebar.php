<div class="row">
  <div class="col-lg-7 col-lg-12">
    <?php get_template_part('template-parts/news/news-block'); ?>
  </div>
  <div class="col-lg-5 col-lg-12">
    <div class="row">
      <div class="col-md-6 col-lg-12">
        <?php get_template_part('template-parts/quick-links/quick-links'); ?>
      </div>
      <div class="col-md-6 col-lg-12">
        <?php get_template_part('template-parts/featured-gallery/featured-gallery'); ?>
      </div>
    </div>
  </div>
</div>