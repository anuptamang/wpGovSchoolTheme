<?php
/*
Template Name: Videos Materials
*/
get_header(); ?>

<?php $the_query = new WP_Query(array('pagename' => 'download/video-teaching-materials')); ?>
  <?php while( $the_query -> have_posts() ) : $the_query -> the_post(); ?> 
  <?php get_template_part('blocks/intro-banner'); ?>
<?php endwhile ?>


<div class="container py-10">
<?php
   $args = array(
               'child_of' => 12,
               'orderby' => 'name',
               'order'   => 'ASC'
           );
   $cats = get_categories($args); ?>
  <?php foreach( $cats as $cat ): ?>
    <a href="<?php echo get_category_link( $cat->term_id ) ?>">
          <?php echo $cat->name; ?>
    </a> 

<?php endforeach ?>
    <h2>बिषयगत सामाग्रिहरु: </h2>
    <div class="row">
      <?php if ( have_posts() ) : ?>
          <?php while ( have_posts() ) : the_post() ?>
            <div class="col-md-3 mb-6 d-flex text-center">
              <a href="<?php echo the_permalink() ?>" class="video-post has-bg" <?php if (has_post_thumbnail( $post->ID ) ) {
            $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'full' );
            echo 'style="background-image: url('.$image[0].')"';        
          } else {
            $placeholder = get_field('banner_blue', 'options');
            echo 'style="background-image: url('.$placeholder.')"';
          }?>>
            <div class="wrap">
              <div class="btn-play"></div>
              <div class="title">
                <h5 class="text-white m-0"><?php the_title() ?></h5>
              </div>
            </div>
          </a>
        </div>
      <?php endwhile ?>
    </div>
    <?php get_template_part( 'blocks/pager' ) ?>
    <?php else : ?>
     <?php get_template_part( 'blocks/not_found' ) ?>
   <?php endif ?>
 </div>

<?php get_footer(); ?>