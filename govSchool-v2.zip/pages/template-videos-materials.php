<?php
/*
Template Name: Videos Materials
*/
get_header(); ?>

<?php get_template_part('blocks/intro-banner'); ?>

<div class="container py-10">
  <?php if( $terms = wp_list_categories( array( 'child_of' => 12, 'title_li' => 'बिषय छान्नुहोस' ) ) ) :  endif;
    ?>
    <div class="featured-video-material mb-6">
    <?php $category = new WP_Query( array('category_name' => 'online_education') ); ?>
      <div class="info-box">
          <h2 class="h4 block-heading bg-primary text-white px-6 py-4 mb-0">भिडियो सिकाई सामाग्रिहरु
          </h2>
          <div class="p-4">
            <div class="row">
              <?php while($category->have_posts()) : $category->the_post(); ?>
              <div class="col-md-3 mb-6 d-flex text-center">
                    <a href="<?php echo the_permalink() ?>" class="video-post has-bg" <?php if (has_post_thumbnail( $post->ID ) ) {
                  $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'full' );
                  echo 'style="background-image: url('.$image[0].')"';        
                } else {
                  $placeholder = get_field('banner_blue', 'options');
                  echo 'style="background-image: url('.$placeholder.')"';
                }?>>
                  <div class="wrap">
                    <div class="btn-play"></div>
                    <div class="title">
                      <h5 class="text-white m-0"><?php the_title() ?></h5>
                    </div>
                  </div>
                </a>
              </div>
              <?php endwhile;
                wp_reset_postdata();
                ?>
            </div>
          </div>
        </div>
    </div>
</div>


<div class="video-materials-section d-none">
  <?php  
    $args = array('post_type' => 'video_materials');
    $loop = new WP_Query($args);?>
   <?php while ($loop->have_posts()) : $loop->the_post(); ?>   
  <section class="section">
    <div class="container-fluid py-8 py-lg-12">
        <div class="info-box">
          <h2 class="h4 block-heading bg-primary text-white px-6 py-4 mb-0"><?php the_title() ?>
          </h2>
          <div class="p-4">
            <div class="row">
              <?php while( have_rows('video_materials') ) : the_row() ?>
              <div class="col-md-4 col-lg-4 mb-6">
                <div class="info-box">
                  <?php if( $video_id = get_sub_field('video_id') ) : endif ?>
                  <?php if( $title = get_sub_field('title') ) : endif ?>
                  <?php if( $class = get_sub_field('class') ) : endif ?>
                  <?php if( $topics = get_sub_field('topics') ) : endif ?>
                  <?php if( $teacher = get_sub_field('teacher') ) : endif ?>
                  <?php if( $note_file = get_sub_field('note_file') ) : endif ?>
                  <div class="video-iframe">
                    <iframe width="560" height="315" src="https://www.youtube.com/embed/<?php echo $video_id ?>" frameborder="0"
                      allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
                      allowfullscreen></iframe>
                  </div>
                  <div class="video-caption bg-primary text-white p-3">
                      <ul class="list-unstyled row mb-0 text-center">
                        <!-- <li class="col-6 ellipsis text-nowrap mb-1">बिषय: <?php echo $title ?></li>
                        <li class="col-6 ellipsis text-nowrap mb-1">कक्षा: <?php echo $class ?></li> -->
                        <li class="col-12 ellipsis text-nowrap mb-1">बिषयबस्तु: <?php echo $topics ?></li>
                        <li class="col-12 ellipsis text-nowrap mb-1">शिक्षक: <?php echo $teacher ?></li>
                        <li class="col-12 text-nowrap"><a class="btn btn-primary bg-danger  btn-sm no-after-icon" href="<?php echo $note_file ?>" target="_blank" download>नोट डाउनलोड गर्नुहोस</a></li>
                      </ul>
                  </div>
                </div>
              </div>
               <?php endwhile ?>  
            </div>
          </div>
        </div>
      </div>
  </section>
  <?php endwhile; ?>
</div>

<?php get_footer(); ?>