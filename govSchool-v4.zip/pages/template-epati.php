<?php
/*
Template Name: e-pati
*/
get_header(); ?>
<?php get_template_part('blocks/intro-banner'); ?>


<?php get_footer(); ?>