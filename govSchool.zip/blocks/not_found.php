<div class="post">
  <div class="head">
    <h1><?php _e( 'केहि भेटिएन!', 'wordpress' ) ?></h1>
  </div>
  <div class="content">
    <p><?php _e( 'माफ गर्नुहोला, तपाईले खोजि गर्नु भएको कुरा भेटिएन!', 'wordpress' ) ?></p>
    <div class="row">
      <div class="col-md-6">
        <?php get_search_form() ?>
      </div>
    </div>
  </div>
</div>
