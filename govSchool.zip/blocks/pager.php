<?php
the_posts_pagination( array(
  'prev_text' => __( 'Previous page', 'wordpress' ),
  'next_text' => __( 'Next page', 'wordpress' ),
) )
?>
