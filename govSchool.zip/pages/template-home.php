<?php
/*
Template Name: Homepage
*/
get_header(); ?>

<?php get_template_part('template-parts/hero/hero-slider'); ?>
<?php get_template_part('template-parts/about/about-section'); ?>
<?php get_template_part('template-parts/news-featured/news-featured-section'); ?>

<?php get_footer(); ?>
